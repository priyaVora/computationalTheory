package vora.priya.computationalTheory;

public interface State {
	void getNextState(String currentSymbol);
}
