package vora.priya.computationalTheory.StateMachine;

public interface State {
	void getNextState(String currentSymbol);
}
