package vora.priya.computationalTheory.ParseTree;

public class Symbol {
	String symbol;
	
	
	public Symbol() { 
		
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
}
